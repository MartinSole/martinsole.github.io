import React, { useState, useEffect, } from "react";
import { unstable_batchedUpdates } from "react-dom";
import Beer from "./Beer";

function App() {
  const [name, setName] = useState('');
  const [tagLine, setTagLine] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState("");
  let tempData = null;
  const getBeer = (e) => {
    e.preventDefault();
    const beerName = document.querySelector('#searchBeer').value;
    fetch(`https://api.punkapi.com/v2/beers?beer_name=${beerName}`).
      then(results => results.json())
      .then(data => {
        // API test
        setName(data[0].name);
        setTagLine(data[0].tagname);
        setDescription(data[0].description);
        setImageUrl(data[0].image_url);
        beerData(data)      
      })
  }

  function beerData(data) {
    const beers = [];
    for(let i in data) {
      beers.push(data[i]);
    }
    console.log(beers)
  }

  return (
    <>
      <header className="header">
        <h1>Brewdog</h1>
        <div className="cart">
          <button className="cart-button btn"><span aria-hidden="true"><i className="fas fa-shopping-cart"></i></span>View cart</button>
        </div>
      </header>
      <main className="container">
        <div className="search-beer-form">
          <form action="POST">
            <label htmlFor="searchBeer">Search Beer</label>
            <input type="text" id="searchBeer" />
            <button className="search-button btn" onClick={getBeer}>Search</button>
          </form>
        </div>
        {name !== '' ?
          <div className="beer-container">
            <Beer
              name={name}
              tagLine={tagLine}
              description={description}
              image={imageUrl}
            />
          </div>
          : <h2 className="search-heading">Search for your favourite beer</h2>
        }
      </main>
      <footer></footer>
    </>
  );
}

export default App;
