import React from 'react';

export default function Beer(props) {
const {name, tagline, description, image} = props
    return(
        <section className="beer">
            <div>
                <div className="beer-text">
                    <h2>{name}</h2>
                    <h3>{tagline}</h3>
                    <p>{description}</p>
                </div>
                <button className="btn">Add to Cart</button>
            </div>
            <img src={image} alt={name} />
        </section>
    )

}